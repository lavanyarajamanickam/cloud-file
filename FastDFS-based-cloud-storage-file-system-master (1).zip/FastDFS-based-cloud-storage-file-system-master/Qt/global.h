#ifndef GLOBAL_H
#define GLOBAL_H

// 正则表达式字符串


#endif // GLOBAL_H
